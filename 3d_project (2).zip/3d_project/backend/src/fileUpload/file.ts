import { Field, ObjectType } from '@nestjs/graphql';
import { prop } from 'typegoose';

@ObjectType()
export class FileObject {

  @Field()
  @prop()
  fileName: string

  @Field()
  @prop()
  size: number

  @Field()
  @prop()
  url: string

}

@ObjectType()
export class DirObject {

  @Field()
  @prop()
  url: string

  @Field()
  @prop()
  size: number

  @Field(type => [FileObject])
  @prop()
  content: string[]

}