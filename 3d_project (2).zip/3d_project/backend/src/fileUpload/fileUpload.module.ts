import { Global, Module } from '@nestjs/common';
import { S3Module } from 'nestjs-s3';
import { FileUploadService } from './fileUpload.service';

@Global()
@Module({
  imports: [
    S3Module.forRoot({
      config: {
        accessKeyId: 'bOCIffuCVDDKD4k3cynd',
        secretAccessKey: '3wWTWrLVlN59528Z008eh7hVnR4PFP1LMuGCq1jG',
        endpoint: 'http://storage.yandexcloud.net',
        s3ForcePathStyle: true,
        signatureVersion: 'v4',
        sslEnabled: false,
      },
    })
  ],
  providers: [
    FileUploadService
  ],
  exports: [
    FileUploadService
  ]
})
export class FileUploadModule {}
