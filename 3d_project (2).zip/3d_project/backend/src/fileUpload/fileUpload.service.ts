import { FileUpload } from './fileUpload';
import { Injectable } from '@nestjs/common';
import { InjectS3, S3 } from 'nestjs-s3';
import { ManagedUpload } from 'aws-sdk/lib/s3/managed_upload';
import { HeadObjectOutput } from 'aws-sdk/clients/s3';

@Injectable()
export class FileUploadService {
  constructor(
    @InjectS3() private readonly s3: S3,
  ) {
  }

  bucketName = process.env.S3_BUCKET_NAME || 'kronstadt'

  async uploadFile(file: FileUpload): Promise<ManagedUpload.SendData> {
    const { filename, createReadStream } = file;
    const fileStream = createReadStream();
    const uploadParams = { Bucket: this.bucketName, Key: filename, Body: fileStream }
    return this.s3.upload(uploadParams).promise()
}

  async getObjectHead(fileName: string): Promise<HeadObjectOutput> {
    return this.s3.headObject({ Bucket: this.bucketName, Key: fileName }).promise()
  }



}