import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ModelModule } from './model/model.module';
import { TypegooseModule } from 'nestjs-typegoose';
import { GraphQLModule } from '@nestjs/graphql';
import { join } from 'path';
import { FileUploadModule } from './fileUpload/fileUpload.module';
import { FileUploadService } from './fileUpload/fileUpload.service';

@Module({
  imports: [
    ModelModule,
    TypegooseModule.forRoot(process.env.DB_URL || 'mongodb://kronstadt:NYduAE8F@rc1b-6wldxqg3thoj38s9.mdb.yandexcloud.net:27018/kronstadt?replicaSet=rs01', {
      useNewUrlParser: true,
      ssl: process.env.SSL === 'true' ? true : false,
      sslValidate: false
    }),
    GraphQLModule.forRoot({
      autoSchemaFile: join(process.cwd(), 'src/schema.gql'),
      context: ({ req, res }) => ({ req, res }),
      uploads: true,
    }),
    FileUploadModule,

  ],
  controllers: [AppController],
  providers: [AppService, FileUploadService],
})
export class AppModule {}
