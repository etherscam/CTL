import { Injectable } from '@nestjs/common';
import { InjectModel } from 'nestjs-typegoose';
import { Model, ModelInput } from '../models/model.model';
import { ReturnModelType } from '@typegoose/typegoose';
import { execSync } from 'child_process';
import { createWriteStream, mkdirSync, writeFileSync } from 'fs';
import { uuid } from 'uuidv4';
import { FileUpload } from '../../fileUpload/fileUpload';
import { sync as rimraf } from 'rimraf';
import { MarkService } from './mark.service';

import { join } from 'path'
import { Types } from 'mongoose';

@Injectable()
export class ModelService {
  constructor(
    @InjectModel(Model) private readonly modelModel: ReturnModelType<typeof Model>,
    private readonly markService: MarkService
  ) { }

  bucketName = process.env.S3_BUCKET_NAME || 'kronstadt'

  // async migrate() {
  //   const models_objs = []
  //   const marks_objs = []
  //
  //   const models = await this.modelModel.find().exec();
  //   //console.log(models)
  //   for (const model of models) {
  //     const obj = model['_doc'];
  //     const newMarks = [];
  //     const relatedMarks = (await this.markService.findRelated(obj._id)).map(el => el['_doc']);
  //     for (const mark of relatedMarks) {
  //       const markObj = {
  //         _id: {"$oid": mark._id},
  //         name: mark.name,
  //         cameraPosition: {
  //           ...mark.cameraPosition['_doc'],
  //           _id: {"$oid": mark.cameraPosition._id },
  //           position: { ...mark.cameraPosition['_doc'].position['_doc'], _id: { "$oid": mark.cameraPosition['_doc'].position['_doc']._id } },
  //           direction: { ...mark.cameraPosition['_doc'].direction['_doc'], _id: { "$oid": mark.cameraPosition['_doc'].direction['_doc']._id } },
  //           up: { ...mark.cameraPosition['_doc'].up['_doc'], _id: { "$oid": mark.cameraPosition['_doc'].up['_doc']._id } }
  //         }
  //       };
  //
  //       marks_objs.push(markObj)
  //       newMarks.push({"$oid": mark._id});
  //
  //     }
  //     models_objs.push({ ...obj, _id: {"$oid": obj._id}, marks: newMarks })
  //   }
  //
  //   const stringified_models = JSON.stringify(models_objs, null, 2);
  //   const stringified_marks = JSON.stringify(marks_objs, null, 2);
  //   writeFileSync(join(process.cwd(), '..', 'mongo-data-models'), stringified_models);
  //   writeFileSync(join(process.cwd(), '..', 'mongo-data-marks'), stringified_marks);
  // }

  async create(modelInput: ModelInput): Promise<Model> {
    //const dir = await this.unzipAndUpload(modelInput.file);
    //console.log(dir)
    const model = await (new this.modelModel(modelInput)).save();
    return model.populate('marks');
  }

  async find(limit: number, page: number): Promise<Model[]> {
    return await this.modelModel.find()
      .limit(limit).skip(limit * page)
      .populate('marks')
      .exec()
  }

  async count(): Promise<number> {
    return await this.modelModel.find().count().populate('marks').exec();
  }

  async findById(id: string): Promise<Model> {
    return await this.modelModel.findById(id)
      .populate('marks')
      .exec();
  }

  async update(id: string, modelInput: ModelInput): Promise<Model> {
    //const updObj = modelInput;

    //if(modelInput.file) updObj.dir = await this.unzipAndUpload(modelInput.file);

    return await this.modelModel.findByIdAndUpdate(id, modelInput, { new: true })
      .populate('marks')
      .exec();
  }

  async delete(id: string): Promise<Model> {
    return await this.modelModel.findByIdAndDelete(id)
      .populate('marks')
      .exec();
  }

  async rearrangeMarks(id: string, marks: Types.ObjectId[]) {
    return await this.modelModel.findByIdAndUpdate(id, { marks: marks }, { new: true }).populate('marks').exec()
  }

  async findByMarkId(id: string): Promise<string> {
    return (await this.modelModel.findOne({ 'marks': Types.ObjectId(id) }))._id
  }

  async unzipAndUpload(file: FileUpload): Promise<string> {
    const uploadId = uuid();

    const { createReadStream } = await file;

    const readStream = createReadStream();
    const writeStream = createWriteStream(`/tmp/${uploadId}.zip`);

    const pipe = readStream.pipe(writeStream)

    const end = new Promise<string>((resolve, reject) => {
      const bucketName = this.bucketName;
      pipe.on('finish', bucketName => {
        mkdirSync(`/tmp/uploads/${uploadId}`);
        execSync(`unzip /tmp/${uploadId}.zip -d /tmp/uploads/${uploadId}`, { stdio: 'inherit' });
        execSync(
          `aws --endpoint-url http://storage.yandexcloud.net s3 cp /tmp/uploads/${uploadId} s3://${this.bucketName}/${uploadId} --recursive`, { stdio: 'inherit' }
        );
        rimraf(`/tmp/uploads/${uploadId}`);
        console.log('done');
        resolve(`https://storage.yandexcloud.net/${this.bucketName}/${uploadId}/tileset.json` as string);
      });
      pipe.on('error', reject);
    });

    return end;

  }
}
