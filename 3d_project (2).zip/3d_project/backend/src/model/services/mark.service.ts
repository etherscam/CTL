import { Injectable } from '@nestjs/common';
import { InjectModel } from 'nestjs-typegoose';
import { ReturnModelType } from '@typegoose/typegoose';
import { FileUploadService } from '../../fileUpload/fileUpload.service';
import { Mark, MarkInput } from '../models/mark.model';
import { Types } from 'mongoose';
import { Model } from '../models/model.model';

@Injectable()
export class MarkService {
  constructor(
    @InjectModel(Mark) private readonly markModel: ReturnModelType<typeof Mark>,
    @InjectModel(Model) private readonly modelModel: ReturnModelType<typeof Model>,
    private readonly fileUploadService: FileUploadService,
  ) {
  }

  async create(modelId: string, markInput: MarkInput): Promise<Mark> {
    const model = await this.modelModel.findById(modelId).exec();
    if (model) {
      const newObj = new this.markModel(markInput);
      const mark: Mark = await newObj.save();
      await this.modelModel.findOneAndUpdate(
        { '_id': modelId },
        { $push: { 'marks': mark._id } },
        { new: true },
      );
      return mark;
    }

  }

  async find(limit: number, page: number): Promise<Mark[]> {
    return await this.markModel.find()
      .limit(limit).skip(limit * page)
      .exec();
  }

  async count(): Promise<number> {
    return await this.markModel.find().count().exec();
  }

  async findById(id: string): Promise<Mark> {
    return await this.markModel.findById(id)
      .exec();
  }

  async update(id: string, markInput: MarkInput): Promise<Mark> {
    return await this.markModel.findByIdAndUpdate(id, markInput, { new: true })
      .exec();
  }

  async delete(id: string): Promise<Mark> {
    return await this.markModel.findByIdAndDelete(id)
      .exec();
  }

  async findRelated(id: string): Promise<Mark[]> {
    return await this.markModel.find({ modelId: id }).exec();
  }

}
