import { Module } from '@nestjs/common';
import { TypegooseModule } from 'nestjs-typegoose';
import { Mark } from './models/mark.model';
import { Model } from './models/model.model';
import { MarkService } from './services/mark.service';
import { ModelService } from './services/model.service';
import { MarkResolver } from './resolvers/mark.resolver';
import { ModelResolver } from './resolvers/model.resolver';

@Module({
  imports: [
    TypegooseModule.forFeature([Model, Mark]),
  ],
  providers: [
    MarkService, MarkResolver,
    ModelService, ModelResolver
  ]
})
export class ModelModule {}
