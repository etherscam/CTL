import { Args, Int, Mutation, Parent, Query, ResolveField, Resolver } from '@nestjs/graphql';
import { ModelService } from '../services/model.service';
import { Model, ModelInput } from '../models/model.model';
import { Mark, MarkInput } from '../models/mark.model';
import { MarkService } from '../services/mark.service';
import { Types } from 'mongoose';

@Resolver(of => Model)
export class ModelResolver {

  constructor(
    private readonly modelService: ModelService,
    private readonly markService: MarkService
  ) {}

  @Query(returns => [Model])
  async getModels(
    @Args('limit', { type: () => Int, nullable: true, defaultValue: 0 }) limit: number,
    @Args('page', { type: () => Int, nullable: true, defaultValue: 0 }) page: number,
  ): Promise<Model[]> {
    return await this.modelService.find(limit, page);
  }

  @Query(returns => Int)
  async getModelsCount(): Promise<number> {
    return await this.modelService.count();
  }

  // @Query(returns => Boolean)
  // async migrate(): Promise<any> {
  //   await this.modelService.migrate()
  //   return true;
  // }

  @Query(returns => Model)
  async getModel(
    @Args('id', { type: () => String }) id: string,
  ): Promise<Model> {
    return await this.modelService.findById(id);
  }

  @Mutation(returns => Model)
  async createModel(
    @Args('input', { type: () => ModelInput }) input: ModelInput,
  ): Promise<Model> {
    return await this.modelService.create(input);
  }

  @Mutation(returns => Model)
  async updateModel(
    @Args('id', { type: () => String }) id: string,
    @Args('input', { type: () => ModelInput }) input: ModelInput,
  ): Promise<Model> {
    return await this.modelService.update(id, input);
  }

  @Mutation(returns => Model)
  async deleteModel(
    @Args('id', { type: () => String }) id: string
  ): Promise<Model> {
    return await this.modelService.delete(id);
  }

  @Mutation(returns => Model)
  async rearrangeMarks(
    @Args('id', { type: () => String }) id: string,
    @Args('marks', { type: () => [String] }) marks: Types.ObjectId[]
  ): Promise<Model> {
    return this.modelService.rearrangeMarks(id, marks);
  }

}
