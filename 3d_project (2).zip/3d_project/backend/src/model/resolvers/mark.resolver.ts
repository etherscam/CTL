import { Args, Int, Mutation, Parent, Query, ResolveField, Resolver } from '@nestjs/graphql';
import { MarkService } from '../services/mark.service';
import { Mark, MarkInput } from '../models/mark.model';
import { Model } from '../models/model.model';
import { ModelService } from '../services/model.service';

@Resolver(of => Mark)
export class MarkResolver {

  constructor(
    private readonly markService: MarkService,
    private readonly modelService: ModelService
  ) {}

  @Query(returns => [Mark])
  async getMarks(
    @Args('limit', { type: () => Int, nullable: true, defaultValue: 0 }) limit: number,
    @Args('page', { type: () => Int, nullable: true, defaultValue: 0 }) page: number,
  ): Promise<Mark[]> {
    const camera = await this.markService.find(limit, page);
    return camera;
  }

  @Query(returns => Int)
  async getMarksCount(): Promise<number> {
    return await this.markService.count();
  }

  @Query(returns => Mark)
  async getMark(
    @Args('id', { type: () => String }) id: string,
  ): Promise<Mark> {
    return await this.markService.findById(id);
  }

  @Mutation(returns => Mark)
  async createMark(
    @Args('modelId', { type: () => String }) modelId: string,
    @Args('input', { type: () => MarkInput }) input: MarkInput,
  ): Promise<Mark> {
    return await this.markService.create(modelId, input);
  }

  @Mutation(returns => Mark)
  async updateMark(
    @Args('id', { type: () => String }) id: string,
    @Args('input', { type: () => MarkInput }) input: MarkInput,
  ): Promise<Mark> {
    return await this.markService.update(id, input);
  }

  @Mutation(returns => Mark)
  async deleteMark(
    @Args('id', { type: () => String }) id: string
  ): Promise<Mark> {
    return await this.markService.delete(id);
  }

  @ResolveField(returns => String)
  async modelId(@Parent() mark: Mark): Promise<string> {
    return await this.modelService.findByMarkId(mark._id.toString())
  }

}
