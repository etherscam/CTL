import { Field, InputType, ObjectType } from '@nestjs/graphql';
import { Point, PointInput } from './point.model';
import { prop } from '@typegoose/typegoose';
import { Types } from 'mongoose';

@ObjectType()
export class Camera {
  @Field(type => String, { nullable: true })
  _id?: Types.ObjectId;

  @Field(type => Point, { nullable: false })
  @prop()
  position: Point

  @Field(type => Point, { nullable: false })
  @prop()
  direction: Point

  @Field(type => Point, { nullable: false })
  @prop()
  up: Point
}

@InputType()
export class CameraInput {
  @Field(type => String, { nullable: true })
  _id?: Types.ObjectId;

  @Field(type => PointInput, { nullable: false })
  position: PointInput

  @Field(type => PointInput, { nullable: false })
  direction: PointInput

  @Field(type => PointInput, { nullable: false })
  up: PointInput
}