import { Field, InputType, ObjectType } from '@nestjs/graphql';
import { Camera, CameraInput } from './camera.model';
import { prop } from '@typegoose/typegoose';
import { Types } from 'mongoose';
import { Model } from './model.model';

@ObjectType()
export class Mark {
  @Field(type => String, { nullable: true })
  _id?: Types.ObjectId;

  @Field({ nullable: false })
  @prop()
  name: string;

  @Field(type => Camera, { nullable: false })
  @prop()
  cameraPosition?: Camera;
}

@InputType()
export class MarkInput {
  @Field(type => String, { nullable: true })
  _id?: Types.ObjectId;

  @Field( { nullable: false })
  name: string;

  @Field(type => CameraInput, { nullable: false })
  cameraPosition: CameraInput;
}
