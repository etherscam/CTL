import { Field, Float, InputType, ObjectType } from '@nestjs/graphql';
import { Types } from 'mongoose';
import { Mark, MarkInput } from './mark.model';
import { FileUpload, GraphQLUpload } from '../../fileUpload/fileUpload';
import { DirObject } from '../../fileUpload/file';
import { prop } from '@typegoose/typegoose';

@ObjectType()
export class Model {
  
  @Field(type => String, { nullable: true })
  _id?: Types.ObjectId;

  @Field({ nullable: false })
  @prop()
  name: string;

  @Field(type => String, { nullable: true })
  @prop()
  dir: string;

  @Field(type => Float, { nullable: false })
  @prop()
  lat: number;

  @Field(type => Float, { nullable: false })
  @prop()
  lng: number;  
  
  @Field(type => Boolean, { nullable: true })
  @prop()
  geoReferenced: boolean;

  @Field(type => [Mark], { nullable: true })
  @prop({ ref: Mark })
  marks: Types.ObjectId[];

}

@InputType()
export class ModelInput {

  @Field({ nullable: true })
  dir?: string;

  @Field({ nullable: false })
  name: string;

  @Field(type => GraphQLUpload, { nullable: true })
  file?: FileUpload;

  @Field(type => Float, { nullable: false })
  lat: number;

  @Field(type => Float, { nullable: false })
  lng: number;

  @Field(type => Boolean, { nullable: true })
  geoReferenced: boolean;

  @Field(type => [String], { nullable: true })
  marks: Types.ObjectId[];

}