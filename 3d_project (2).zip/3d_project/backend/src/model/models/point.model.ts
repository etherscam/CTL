import { Field, InputType, ObjectType } from '@nestjs/graphql';
import { prop } from '@typegoose/typegoose';

@ObjectType()
export class Point {
  @Field(type => Number, { nullable: false })
  @prop()
  x: number;

  @Field(type => Number, { nullable: false })
  @prop()
  y: number;

  @Field(type => Number, { nullable: false })
  @prop()
  z: number;
}

@InputType()
export class PointInput {
  @Field(type => Number, { nullable: false })
  x: number;

  @Field(type => Number, { nullable: false })
  y: number;

  @Field(type => Number, { nullable: false })
  z: number;
}