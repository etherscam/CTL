const withImages = require('next-images')
const withPlugins = require("next-compose-plugins");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const path = require("path");

const config = {
    webpack: (config, {buildId, dev, isServer, defaultLoaders, webpack}) => {
        try {
            config.externals.cesium = "Cesium";
        } catch {
            config.externals = {
                cesium: "Cesium",
            };
        }
        if (isServer) {
            config.plugins.push(new CopyWebpackPlugin({
                patterns:
                    [{
                        from: path.join(__dirname, (dev ?
                            "node_modules/cesium/Build/CesiumUnminified/" :
                            "node_modules/cesium/Build/Cesium/")),
                        to: path.join(__dirname, "static/Cesium"),
                    }
                    ]
            }));
        }
        config.plugins.push(new HtmlWebpackPlugin({}));
        config.plugins.push(new webpack.DefinePlugin({
            CESIUM_BASE_URL: JSON.stringify("static/Cesium"),
        }));

        config.module.rules.push({
            test: /\.(eot|otf|ttf|woff|woff2)$/,
            use: {
                loader: "url-loader",
                options: {
                    limit: 8192,
                    publicPath: "/_next/static/",
                    outputPath: "static/",
                    name: "[name].[ext]"
                }
            }
        });
        return config;
    },
    env: {
        apiUrl: 'http://localhost:5500/graphql',
    },
};

module.exports = withPlugins([withImages], config)
