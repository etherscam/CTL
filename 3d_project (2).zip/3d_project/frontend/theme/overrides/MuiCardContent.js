import palette from '../palette';
import typography from '../typography';

export default {
    root: {
        padding: '2rem',
        '&:last-child': {
            paddingBottom: '2rem'
        },
    }
};
