export const VALID_LOGIN = {
    user1: {
        password: "FG7LeT",
        type: "admin"
    },
    user2: {
        password: "889qJt",
        type: "admin"
    },
    user3: {
        password: "W5chS5",
        type: "user"
    },
    user4: {
        password: "Hqm8fz",
        type: "user"
    },
    user5: {
        password: "H44HjN",
        type: "user"
    },
}