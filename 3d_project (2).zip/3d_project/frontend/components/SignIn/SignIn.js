import React from 'react';
import {makeStyles} from '@material-ui/styles';
import {Grid, Button, TextField, Typography} from '@material-ui/core';
import {useForm} from "react-hook-form";
import cookies from 'js-cookie'
import {useRouter} from "next/router";
import {VALID_LOGIN} from "contants";

const useStyles = makeStyles(theme => ({
    root: {
        height: '100%',
        flex: 1
    },
    window: {
        height: '100%',
        width: '60%',
        maxWidth: '600px',
        margin: 'auto',
        display: 'flex',
        alignItems: 'center',
        flex: 1
    },
    grid: {
        [theme.breakpoints.down('md')]: {
            justifyContent: 'center'
        },
        background: 'white',
        border: "1px solid #9EA0A5"
    },
    right: {
        display: 'flex',
        justifyContent: 'center',
        backgroundColor: theme.palette.primary.main,
        alignItems: 'flex-start',
        [theme.breakpoints.down('md')]: {
            display: 'none'
        }
    },
    left: {
        padding: theme.spacing(5),

    },
    title: {
        marginBottom: theme.spacing(1)
    },
    text: {
        marginBottom: theme.spacing(2)
    },
    textField: {
        marginBottom: theme.spacing(2),
        marginTop: theme.spacing(2)
    },
    signInButton: {
        marginTop: theme.spacing(3)
    }
}));

const SignIn = props => {
    const classes = useStyles();
    const {register, errors, handleSubmit, setError} = useForm();
    const router = useRouter();
    const validateUser = (formData) => {
        if (VALID_LOGIN[formData.login]?.password === formData.password) {
            cookies.set('type', VALID_LOGIN[formData.login].type, {expires: 30});
            router.push('/models');
        } else {
            [
                {name: 'login', type: "invalid", message: "Неверный логин или пароль"},
                {name: 'password', type: "invalid", message: "Неверный логин или пароль"}
            ].forEach(({name, type, message}) => setError(name, { type, message }))
        }
    }

    return (
        <div className={classes.root}>
            <div className={classes.window}>
                <Grid className={classes.grid} container>
                    <Grid className={classes.left} item xs={12}>
                        <form className={classes.form} autoComplete="off" onSubmit={handleSubmit(validateUser)}>
                            <Typography className={classes.title} variant="h3">Авторизация</Typography>
                            <Typography className={classes.text} color="textSecondary">Введите логин и пароль</Typography>
                            <TextField
                                className={classes.textField}
                                fullWidth
                                label="Логин"
                                name="login"
                                type="text"
                                variant="outlined"
                                autoComplete="off"
                                error={errors.login || errors.password}
                                helperText={errors?.login?.message}
                                inputRef={register({required: "Обязательное поле"})}
                            />
                            <TextField
                                className={classes.textField}
                                fullWidth
                                label="Пароль"
                                name="password"
                                type="password"
                                variant="outlined"
                                autoComplete="off"
                                error={errors.login || errors.password}
                                helperText={errors?.password?.message}
                                inputRef={register({required: "Обязательное поле"})}
                            />
                            <Button
                                className={classes.signInButton}
                                color="secondary"
                                fullWidth
                                size="large"
                                type="submit"
                                variant="contained"
                            >
                                Войти
                            </Button>
                        </form>

                    </Grid>
                    {/*<Grid className={classes.right} item lg={5}>*/}
                        {/*<img src={require('../../images/sign-logo.png')}/>*/}
                    {/*</Grid>*/}
                </Grid>
            </div>

        </div>
    );
};

export default SignIn;
