import React, {useState} from 'react';
import {
    makeStyles,
    DialogContent,
    DialogActions,
    Dialog,
    DialogTitle,
    Button,
    Typography,
    Grid,
    TextField,
    FormControlLabel,
    Checkbox, LinearProgress
} from '@material-ui/core';
import {useForm} from "react-hook-form";
import {useMutation} from "@apollo/client";
import {CREATE_MODEL} from "graphql/Model/createModel";
import filesize from "filesize";

const useStyles = makeStyles(theme => ({
    root: {
        padding: theme.spacing(7),
    },
    input: {
        display: 'none',
    },
    content: {
        flex: 1
    },
    dialog: {
        minWidth: "400px",
        '& .MuiTypography-h6': {
            '& span': {
                color: theme.palette.error.main
            }
        }
    },
    row: {
        marginBottom: theme.spacing(3)
    },
    fileName: {
        marginTop: theme.spacing(1)
    },
    title: {
        marginTop: theme.spacing(1)
    },
    checkbox: {
        marginLeft: -12
    }
}));


const ModelDialog = (props) => {
        const classes = useStyles();
        const {open, setOpen, refetch} = props;
        const {register, errors, handleSubmit, getValues, reset} = useForm();
        const [geoRef, setGeoRef] = useState(false);
        const [createModel] = useMutation(CREATE_MODEL);
        const [loaded, setLoaded] = useState(true)

        const handleClose = () => {
            setOpen(false);
            reset();
            setTimeout(() => {
                reset();
            }, 1000)
        };

        const handleChange = () => {
            setGeoRef(!geoRef);
        };

        const sendData = (data) => {
            setLoaded(false)
            createModel({
                variables: {
                    input: {
                        ...data,
                        geoReferenced: geoRef,
                        lng: parseFloat(data.lng),
                        lat: parseFloat(data.lat),
                    },
                }
            }).then((e) => {
                setTimeout(() => setLoaded(true), 1000)
                handleClose()
                refetch()
            })
        }

        return (
            <Dialog
                open={open}
                onClose={handleClose}
                aria-labelledby="responsive-dialog-title"
                classes={{paper: classes.dialog}}
                disableBackdropClick={!loaded}
                disableEscapeKeyDown={!loaded}
            >
                <DialogTitle id="alert-dialog-title"><Typography variant="h5">Добавление модели</Typography></DialogTitle>
                <form onSubmit={handleSubmit(data => sendData(data))} autoComplete="off">
                    <DialogContent>
                        {loaded ?
                            <>
                                <div className={classes.row}>
                                    <Grid container alignItems={'center'}>
                                        <Grid item xs={4}>
                                            <Typography variant="h6">Название <span>*</span></Typography>
                                        </Grid>
                                        <Grid item xs={8}>
                                            <TextField id="outlined-basic-3"
                                                       name="name"
                                                       fullWidth
                                                       error={errors.name}
                                                       helperText={errors.name && "Обязательное поле"}
                                                       inputRef={register({required: true})}
                                                       variant="outlined" size={'small'}/>
                                        </Grid>
                                    </Grid>
                                </div>
                                <div className={classes.row}>
                                    <Grid container alignItems={'center'}>
                                        <Grid item xs={4}>
                                            <Typography variant="h6">Широта <span>*</span></Typography>
                                        </Grid>
                                        <Grid item xs={8}>
                                            <TextField id="outlined-basic-3"
                                                       name="lat"
                                                       fullWidth
                                                       error={errors.lat?.type === 'required'}
                                                       type="number"
                                                       InputProps={{
                                                           inputProps: {
                                                               step: "any"
                                                           }
                                                       }}
                                                       helperText={errors.lat && "Обязательное поле"}
                                                       inputRef={register({required: true})}
                                                       variant="outlined" size={'small'}/>
                                        </Grid>
                                    </Grid>
                                </div>
                                <div className={classes.row}>
                                    <Grid container alignItems={'center'}>
                                        <Grid item xs={4}>
                                            <Typography variant="h6">Долгота <span>*</span></Typography>
                                        </Grid>
                                        <Grid item xs={8}>
                                            <TextField id="outlined-basic-3"
                                                       name="lng"
                                                       fullWidth
                                                       error={errors.lng}
                                                       type="number"
                                                       InputProps={{
                                                           inputProps: {
                                                               step: "any"
                                                           }
                                                       }}
                                                       helperText={errors.lng && "Обязательное поле"}
                                                       inputRef={register({required: true})}
                                                       variant="outlined" size={'small'}/>
                                        </Grid>
                                    </Grid>
                                </div>
                                <div className={classes.row}>
                                    <Grid container>
                                        <Grid item xs={4}>
                                            <Typography variant="h6"
                                                        className={classes.title}>Файл (ссылка) <span>*</span></Typography>
                                        </Grid>
                                        <Grid item xs={8}>
                                            <TextField id="outlined-basic-3"
                                                       name="dir"
                                                       fullWidth
                                                       error={errors.dir}
                                                       helperText={errors.dir && "Обязательное поле"}
                                                       inputRef={register({required: true})}
                                                       variant="outlined" size={'small'}/>
                                            {/*<input*/}
                                            {/*    // accept="image/csv"*/}
                                            {/*    // accept="image/*"*/}
                                            {/*    className={classes.input}*/}
                                            {/*    id="contained-button-file"*/}
                                            {/*    type="file"*/}
                                            {/*    name="file"*/}
                                            {/*    onChange={(e) => setFile(e.target.files[0])}*/}
                                            {/*/>*/}
                                            {/*<label htmlFor="contained-button-file" className={classes.btnView}>*/}
                                            {/*    <Button variant="contained" color="secondary" component="span">*/}
                                            {/*        Обзор*/}
                                            {/*    </Button>*/}
                                            {/*</label>*/}
                                            {/*{file &&*/}
                                            {/*<Typography variant="h6"*/}
                                            {/*            className={classes.fileName}>{file.name} {file && "—"} {file && filesize(file.size)}</Typography>*/}
                                            {/*}*/}
                                        </Grid>
                                    </Grid>
                                </div>

                                <Grid container alignItems={'center'}>
                                    <Grid item xs={4}>
                                        <Typography variant="h6">Геопривязка</Typography>
                                    </Grid>
                                    <Grid item xs={8}>
                                        <Checkbox checked={geoRef} onChange={handleChange} name="geoRef"
                                                  className={classes.checkbox}/>
                                    </Grid>
                                </Grid>

                            </>
                            : <LinearProgress/>
                        }
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleClose}>Отмена</Button>
                        <Button type="submit" color="primary">Сохранить</Button>
                    </DialogActions>
                </form>

            </Dialog>
        );
    }
;

export default ModelDialog;
