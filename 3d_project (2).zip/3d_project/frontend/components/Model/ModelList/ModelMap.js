import React, {useState} from 'react';

import {makeStyles} from '@material-ui/core';
import {GoogleMap, LoadScript, Marker} from '@react-google-maps/api';
import RoomIcon from '@material-ui/icons/Room';
import clsx from "clsx";

const useStyles = makeStyles(theme => ({
    root: {
        // paddingLeft: 256
    },
    content: {
        height: '100%',
        width: '100%',
        flex: '1 0 auto',
        display: 'flex',
        outline: 0,
        zIndex: 1100,
        position: 'fixed',
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),

    },
    contentShift: {
        width: 'calc(100% - 256px)',
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen,
        }),
    }
}));

const ModelMap = (props) => {
    const classes = useStyles();
    const {models, selected, isOpen, setOpen} = props;
    const [map, setMap] = React.useState(null)
    const containerStyle = {
        width: '100%',
        // height: '600px'
    };
    const onLoad = React.useCallback(function callback(map) {
        if (models.length !== 0) {
            let bounds = new window.google.maps.LatLngBounds();
            models.map((model) => bounds.extend(new google.maps.LatLng(model.lat, model.lng)))
            map.fitBounds(bounds);
        }
        setMap(map)
    }, [])

    const onUnmount = React.useCallback(function callback(map) {
        setMap(null)
    }, [])

    const center = {
        lat: 60,
        lng: 100
    };

    return (
        <div className={classes.root}>
            <div className={clsx(classes.content, {
                [classes.contentShift]: isOpen,
            })}>
                <LoadScript
                    googleMapsApiKey="AIzaSyCSR48D0PpsVLiNppzCJsDCPHVJAD-umKc"
                >
                    <GoogleMap
                        onLoad={onLoad}
                        onUnmount={onUnmount}
                        mapContainerStyle={containerStyle}
                        center={selected ? {lat: selected.lat, lng: selected.lng} : center}
                        zoom={4}
                    >
                        { /* Child components, such as markers, info windows, etc. */}
                        {models.map((model) => (
                            <Marker
                                position={{lat: model.lat, lng: model.lng}}
                                animation={2}
                                onClick={() => window.open(`/model?id=${model._id}`)}
                                icon={{
                                    url: selected === model ? require("../../../images/marker-active.svg") : require("../../../images/marker.svg"),
                                    scaledSize: {width: 40, height: 40},
                                    anchor: {x: 20, y: 40}
                                }}
                            />

                        ))}
                    </GoogleMap>
                </LoadScript>
            </div>
        </div>
    );
};

export default React.memo(ModelMap);
