import React, {useEffect, useState} from 'react';
import cookies from 'js-cookie'
import {
    Box,
    makeStyles,
    List,
    ListSubheader,
    ListItem,
    ListItemText,
    ListItemSecondaryAction,
    IconButton,
    Drawer,
    Typography,
    CircularProgress
} from '@material-ui/core';
import DeleteIcon from '@material-ui/icons/Delete';
import AddIcon from '@material-ui/icons/Add';
import {useQuery, useMutation} from "@apollo/client";
import {GET_MODELS} from "graphql/Model/getModels";
import {DELETE_MODEL} from "graphql/Model/deleteModel";
import ModelMap from "components/Model/ModelList/ModelMap";
import DialogConfirm from "components/DialogConfirm";
import ModelDialog from "components/Model/ModelList/ModelDialog";
import clsx from "clsx";

const useStyles = makeStyles(theme => ({
    root: {
        flex: 1,
    },
    drawerPaper: {
        width: 256,
        top: 64,
        paddingTop: 10,
        height: 'calc(100% - 64px)'
    },
    subheader: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingRight: '15px',
        marginBottom: theme.spacing(1)
    },
    map: {
        height: '100%',
        width: '100%',
        flex: '1 0 auto',
        display: 'flex',
        outline: 0,
        zIndex: 1100,
        position: 'fixed',
        transition: theme.transitions.create('margin', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        marginLeft: 0,
    },
    mapShift: {
        transition: theme.transitions.create('margin', {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen,
        }),
        marginLeft: 256,
    },
    logo: {
        marginTop: 'auto',
        marginLeft: 'auto',
        marginRight: 'auto',
        width: "70%"
    },
    drawerContainer: {
        paddingBottom: '15px',
    }


}));

const ModelList = (props) => {
    const classes = useStyles();
    const {isOpen, setOpen} = props;
    const {data, loading, error, refetch} = useQuery(GET_MODELS);
    const [openDialogCreate, setOpenDialogCreate] = useState(false)
    const [openDialogDelete, setOpenDialogDelete] = useState(false)
    const [id, setId] = useState(false)
    const [selected, setSelected] = useState(null)
    const [deleteModel] = useMutation(DELETE_MODEL);
    const [userType, setUserType] = useState(null)

    useEffect(() => {
        setUserType(cookies.get('type'))
    }, [])

    const handleOpenDialogConfirm = (id) => {
        setId(id);
        setOpenDialogDelete(true);
    };

    const _deleteModel = () => {
        deleteModel({variables: {id}});
        setOpenDialogDelete(false);
        refetch()
    }
    const handleToggle = (value) => () => {
        if (selected === value) {
            setSelected(null)
        } else {
            setSelected(value);
        }
    };

    return (
        <div className={classes.root}>
            {(loading || error) ? <div/> :
                <div className={classes.content}>
                    <Drawer
                        anchor="left"
                        className={classes.drawer}
                        classes={{
                            paper: classes.drawerPaper,
                        }}
                        onClose={() => setOpen(false)}
                        open={isOpen}
                        variant="permanent"
                    >
                        <div className={classes.drawerContainer}>
                            <Box
                                height="100%"
                                display="flex"
                                flexDirection="column"
                            >
                                <List
                                    subheader={
                                        <div className={classes.subheader}>
                                            <ListSubheader component="div" id="list-subheader">
                                                <Typography variant="h4">Модели</Typography>

                                            </ListSubheader>
                                            {userType === 'admin' &&
                                            <IconButton onClick={setOpenDialogCreate}><AddIcon/></IconButton>}
                                        </div>
                                    }
                                >
                                    {data.getModels.map((model, index) =>
                                        <ListItem button key={model} id={`list-item-${index}`}
                                                  onClick={handleToggle(model)} selected={selected === model}>
                                            <ListItemText primary={model.name}/>
                                            {userType === 'admin' &&
                                            <ListItemSecondaryAction>
                                                <IconButton
                                                    onClick={() => handleOpenDialogConfirm(model._id)}><DeleteIcon/></IconButton>
                                            </ListItemSecondaryAction>
                                            }
                                        </ListItem>
                                    )}
                                </List>
                            </Box>
                        </div>
                        <img src="/CTRL2GO.PNG" className={classes.logo}/>
                    </Drawer>
                    <div className={clsx(classes.map, {
                        [classes.mapShift]: isOpen,
                    })}>
                    <ModelMap models={data.getModels} selected={selected} isOpen={isOpen} setOpen={setOpen}/>
                    </div>
                    <ModelDialog open={openDialogCreate} setOpen={setOpenDialogCreate} refetch={refetch}/>
                    <DialogConfirm open={openDialogDelete} setOpen={setOpenDialogDelete}
                                   deleteItem={_deleteModel}
                                   id={id}
                                   dialogText={"Вы действительно хотите удалить модель?"}/>
                </div>
            }
        </div>
    );
};

export default ModelList;
