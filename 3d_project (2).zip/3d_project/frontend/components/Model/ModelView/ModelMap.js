import React, {useEffect, useRef, useState} from 'react';
import {makeStyles} from '@material-ui/core';
import * as Cesium from 'cesium';
import clsx from 'clsx';

const useStyles = makeStyles(theme => ({
    root: {
        // paddingLeft: 256,
    },
    content: {
        height: '100%',
        width: '100%',
        flex: '1 0 auto',
        display: 'flex',
        outline: 0,
        zIndex: 1100,
        position: 'fixed',
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),

    },
    contentShift: {
        width: 'calc(100% - 256px)',
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen,
        }),
    }

}));
Cesium.Ion.defaultAccessToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI5ZGFiYzI4NS0xYmU2LTRkY2UtODJlZC05ZTBiMWQyMDUwODciLCJpZCI6MzU3NDAsImlhdCI6MTYwMjQ5NDQyMn0.cSfUiH9P6ifb6FCU_1IjCoYMtIPehlGmZTOZcJtiUDw';

const ModelMap = (props) => {
    const classes = useStyles();
    const {viewer, model, selected, isOpen} = props;

    const geoReferenced = model.geoReferenced;

    useEffect(() => {
        var terrainModels = Cesium.createDefaultTerrainProviderViewModels();

        let options = {
            timeline: false,
            animation: false,
            scene3DOnly: true,
        }

        if(geoReferenced) {
            options.terrainProviderViewModels = terrainModels;
            options.selectedTerrainProviderViewModel = terrainModels[1];
        } else {
            options.terrainProvider = Cesium.createWorldTerrain();
        }

        viewer.current = new Cesium.Viewer('cesiumContainer', options)

        viewer.current.scene.globe.depthTestAgainstTerrain = false;

        const tileset = new Cesium.Cesium3DTileset({
            url: model.dir,
            maximumScreenSpaceError: 1, // Temporary workaround for low memory mobile devices - Increase maximum error to 8.
            maximumNumberOfLoadedTiles: 1000, // Temporary workaround for low memory mobile devices - Decrease (disable) tile cache.
            // url: 'https://storage.yandexcloud.net/spo-files/1111/tileset.json',
        });
        viewer.current.scene.primitives.add(tileset);
        viewer.current.zoomTo(tileset);
        viewer.current.scene.frameState.creditDisplay.addDefaultCredit(new Cesium.Credit(`<a href="https://ctrl4tver3d.ru/" target="_blank"><img src="/static/CTRL2GO.PNG" title="Ctrl2Go!" style="height:25px"/></a>`));
        if (!geoReferenced) {
            viewer.current.scene.skyAtmosphere.show = false;
            viewer.current.scene.fog.enabled = false;
            viewer.current.scene.globe.showGroundAtmosphere = false;
            viewer.current.scene.imageryLayers.removeAll();
            viewer.current.scene.globe.baseColor = Cesium.Color.BLACK;
            viewer.current.scene.skyBox.destroy();
            viewer.current.scene.skyBox = undefined;
            viewer.current.scene.sun.destroy();
            viewer.current.scene.sun = undefined;
            tileset.readyPromise.then(function () {
                let longitude = 0;
                let latitude = 0;
                let height = 18;
                let cartesian = Cesium.Cartesian3.fromDegrees(longitude, latitude, height);
                let transform = Cesium.Transforms.headingPitchRollToFixedFrame(cartesian, new Cesium.HeadingPitchRoll());
                tileset._root.transform = Cesium.Matrix4.IDENTITY;
                tileset.modelMatrix = transform;
                viewer.zoomTo(tileset, new Cesium.HeadingPitchRange(0.0, -0.5, tileset.boundingSphere.radius / 4.0));
            });
        }
    }, [])

    useEffect(() => {
        if (selected) {
            viewer.current.camera.flyTo({
                destination: new Cesium.Cartesian3(selected.cameraPosition.position.x, selected.cameraPosition.position.y, selected.cameraPosition.position.z),
                orientation: {
                    direction: new Cesium.Cartesian3(selected.cameraPosition.direction.x, selected.cameraPosition.direction.y, selected.cameraPosition.direction.z),
                    up: new Cesium.Cartesian3(selected.cameraPosition.up.x, selected.cameraPosition.up.y, selected.cameraPosition.up.z),
                }
            })
        } else {
            // viewer.current.camera.flyHome()
        }

    }, [selected])

    // const position = Cartesian3.fromDegrees(-74.0707383, 40.7117244, 100);

    return (
        <div className={classes.root}>
            <div className={clsx(classes.content, {
                [classes.contentShift]: isOpen,
            })} id={'cesiumContainer'}/>
            {/*<Viewer full>*/}
            {/*<Entity*/}
            {/*    name="test"*/}
            {/*    description="test!!"*/}
            {/*    position={Cartesian3.fromDegrees(-74.0707383, 40.7117244, 100)}*/}
            {/*    point={{ pixelSize: 10 }}*/}
            {/*/>*/}
            {/*<Cesium3DTileset url={'https://storage.yandexcloud.net/spo-files/1111/tileset.json'}/>*/}

            {/*</Cesium3DTileset>*/}
            {/*<Entity position={position}>*/}
            {/*    <PointGraphics pixelSize={10} />*/}
            {/*</Entity>*/}
            {/*</Viewer>*/}
        </div>
    );
};

export default React.memo(ModelMap);
