import React, {useRef, useState, useEffect} from 'react';
import cookies from 'js-cookie'
import clsx from 'clsx';
import {
    Box,
    makeStyles,
    List,
    ListSubheader,
    ListItem,
    ListItemText,
    ListItemSecondaryAction,
    IconButton,
    Drawer,
    ListItemIcon,
    Typography,
    RootRef,
    CircularProgress
} from '@material-ui/core';
import DeleteIcon from '@material-ui/icons/Delete';
import AddIcon from '@material-ui/icons/Add';
import {useQuery, useMutation} from "@apollo/client";
import {DELETE_MODEL} from "graphql/Model/deleteModel";
import DialogConfirm from "components/DialogConfirm";
import ModelDialog from "components/Model/ModelList/ModelDialog";
import {GET_MODEL} from "graphql/Model/getModel";
import ModelMarkDialog from "components/Model/ModelView/ModelMarkDialog";
import dynamic from 'next/dynamic'
import {DELETE_MARK} from "graphql/Mark/deleteMark";
import {DragDropContext, Droppable, Draggable} from "react-beautiful-dnd";
import {REORDER_MARKS} from "graphql/Mark/reorderMarks";

const ModelMap = dynamic(
    () => import('components/Model/ModelView/ModelMap'),
    {ssr: false})

const useStyles = makeStyles(theme => ({
    root: {
        flex: 1,
    },
    map: {
        backgroundColor: "black",
        height: '100%',
        width: '100%',
        flex: '1 0 auto',
        display: 'flex',
        outline: 0,
        zIndex: 1100,
        position: 'fixed',
        transition: theme.transitions.create('margin', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        marginLeft: 0,
    },
    mapShift: {
        transition: theme.transitions.create('margin', {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen,
        }),
        marginLeft: 256,
    },
    drawerPaper: {
        width: 256,
        top: 64,
        paddingTop: 10,
        height: 'calc(100% - 64px)'
    },
    subheader: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingRight: '15px',
        marginBottom: theme.spacing(1)
    },
    logo: {
        marginTop: 'auto',
        marginLeft: 'auto',
        marginRight: 'auto',
        width: "70%"
    },
    drawerContainer: {
        paddingBottom: '15px',
    },
    listItem: {
        // paddingRight: '60px'
    },
    icon: {
        top: '50%',
        right: '16px',
        position: 'absolute',
        transform: 'translateY(-50%)',
        minWidth: 'auto'
    }

}));

const ModelView = (props) => {
    const classes = useStyles();
    const {id, isOpen, setOpen} = props;
    const {data, loading, error, refetch} = useQuery(GET_MODEL, {variables: {id}});
    const [openDialogCreate, setOpenDialogCreate] = useState(false)
    const [openDialogDelete, setOpenDialogDelete] = useState(false)
    const [selected, setSelected] = useState(null)
    const [markId, setMarkId] = useState(null)
    const [deleteMark] = useMutation(DELETE_MARK);
    const [reorderMarks] = useMutation(REORDER_MARKS);
    const [userType, setUserType] = useState(null)
    const [marks, setMarks] = useState(null)
    const viewer = useRef(null)

    useEffect(() => {
        setUserType(cookies.get('type'))
    }, [])

    useEffect(() => {
        if (data) {
            setMarks(data.getModel.marks)
        }
    }, [loading, data])

    const handleOpenDialogConfirm = (id) => {
        setOpenDialogDelete(true);
        setMarkId(id)
    };

    const _deleteMark = () => {
        deleteMark({variables: {id: markId}});
        setOpenDialogDelete(false);
        refetch()
    }
    const reorder = (list, startIndex, endIndex) => {
        const result = Array.from(list);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return result;
    };

    const onDragEnd = (result) => {
        if (!result.destination) {
            return;
        }

        const items = reorder(
            marks,
            result.source.index,
            result.destination.index
        );
        setMarks(items)
        reorderMarks({variables: {marks: items.map(item => item._id), id}}).then(() => refetch())

    }

    const handleToggle = (value) => () => {
        if (selected === value) {
            setSelected(null)
        } else {
            setSelected(value);
        }
    };
    const getItemStyle = (isDragging, draggableStyle) => ({
        ...draggableStyle,

        ...(isDragging && {
            background: "rgb(235,235,235)"
        })
    });
    const getListStyle = isDraggingOver => ({
        //background: isDraggingOver ? 'lightblue' : 'lightgrey',
    });
    return (
        <div className={classes.root}>
            {(loading || error) ? <div/> :
                <div className={classes.content}>
                    <DragDropContext onDragEnd={onDragEnd}>
                        <Droppable droppableId="droppable">
                            {(provided, snapshot) => (
                                <Drawer
                                    anchor="left"
                                    className={classes.drawer}
                                    classes={{
                                        paper: classes.drawerPaper,
                                    }}
                                    onClose={() => setOpen(false)}
                                    open={isOpen}
                                    variant="permanent"
                                >
                                    <div className={classes.drawerContainer}>
                                        <Box
                                            height="100%"
                                            display="flex"
                                            flexDirection="column"
                                        >
                                            <RootRef rootRef={provided.innerRef}>
                                                <List style={getListStyle(snapshot.isDraggingOver)}
                                                      subheader={
                                                          <div className={classes.subheader}>
                                                              <ListSubheader component="div" id="list-subheader">
                                                                  <Typography variant="h4">Закладки</Typography>

                                                              </ListSubheader>
                                                              {userType === 'admin' &&
                                                              <IconButton
                                                                  onClick={setOpenDialogCreate}><AddIcon/></IconButton>}
                                                          </div>
                                                      }
                                                >
                                                    {marks?.map((mark, index) =>
                                                        <Draggable key={mark._id} draggableId={mark._id} index={index}>
                                                            {(provided, snapshot) => (
                                                                <div ref={provided.innerRef}
                                                                     {...provided.draggableProps}
                                                                     {...provided.dragHandleProps}
                                                                     style={getItemStyle(
                                                                         snapshot.isDragging,
                                                                         provided.draggableProps.style
                                                                     )}
                                                                >
                                                                <ListItem button key={mark} id={`list-item-${index}`}
                                                                          className={classes.listItem}
                                                                          onClick={handleToggle(mark)}
                                                                          selected={selected === mark}>
                                                                    <ListItemText primary={mark.name}/>
                                                                    {userType === 'admin' &&
                                                                    <ListItemSecondaryAction>
                                                                        <IconButton
                                                                            onClick={() => handleOpenDialogConfirm(mark._id)}><DeleteIcon/></IconButton>
                                                                    </ListItemSecondaryAction>

                                                                    }

                                                                </ListItem>
                                                                </div>
                                                            )}
                                                        </Draggable>
                                                    )}
                                                    {provided.placeholder}
                                                </List>
                                            </RootRef>

                                        </Box>

                                    </div>
                                    <img src="/CTRL2GO.PNG" className={classes.logo}/>

                                </Drawer>
                            )}
                        </Droppable>
                    </DragDropContext>
                    <div className={clsx(classes.map, {
                        [classes.mapShift]: isOpen,
                    })}>
                        <ModelMap model={data.getModel} viewer={viewer} selected={selected} isOpen={isOpen}/>
                    </div>
                    <ModelMarkDialog open={openDialogCreate} setOpen={setOpenDialogCreate} refetch={refetch}
                                     viewer={viewer} modelId={data.getModel._id}/>
                    <DialogConfirm open={openDialogDelete} setOpen={setOpenDialogDelete}
                                   deleteItem={_deleteMark}
                                   dialogText={"Вы действительно хотите удалить закладку?"}/>
                </div>
            }
        </div>
    );
};

export default ModelView;
