import React, {useState} from 'react';
import {
    makeStyles,
    DialogContent,
    DialogActions,
    Dialog,
    DialogTitle,
    Button,
    Typography,
    Grid,
    TextField,
    LinearProgress
} from '@material-ui/core';
import {useForm} from "react-hook-form";
import {useMutation} from "@apollo/client";
import {CREATE_MODEL} from "graphql/Model/createModel";
import filesize from "filesize";
import {CREATE_MARK} from "graphql/Mark/createMark";

const useStyles = makeStyles(theme => ({
    root: {
        padding: theme.spacing(7),
    },
    input: {
        display: 'none',
    },
    content: {
        flex: 1
    },
    dialog: {
        minWidth: "400px",
        '& .MuiTypography-h6': {
            '& span': {
                color: theme.palette.error.main
            }
        }
    },
    row: {
        marginBottom: theme.spacing(3)
    },
    fileName: {
        marginTop: theme.spacing(1)
    },
    title: {
        marginTop: theme.spacing(1)
    }
}));


const ModelMarkDialog = (props) => {
        const classes = useStyles();
        const {open, setOpen, refetch, viewer, modelId} = props;
        const {register, errors, handleSubmit, getValues, reset} = useForm();
        const [createMark] = useMutation(CREATE_MARK);
        const [loaded, setLoaded] = useState(true)

        const handleClose = () => {
            setOpen(false);
            setTimeout(() => reset(), 1000)
        };

        const sendData = (data) => {
            setLoaded(false)
            createMark({
                variables: {
                    modelId: modelId,
                    input: {
                        ...data,
                        cameraPosition: {
                            position: viewer.current.camera.position,
                            direction: viewer.current.camera.direction,
                            up: viewer.current.camera.up,
                        }
                    },
                }
            }).then((e) => {
                setTimeout(() => setLoaded(true), 1000)
                handleClose()
                refetch()
            })
        }

        return (
            <Dialog
                open={open}
                onClose={handleClose}
                aria-labelledby="responsive-dialog-title"
                classes={{paper: classes.dialog}}
                disableBackdropClick={!loaded}
                disableEscapeKeyDown={!loaded}
            >
                <DialogTitle id="alert-dialog-title"><Typography variant="h5">Добавление закладки</Typography></DialogTitle>
                <form onSubmit={handleSubmit(data => sendData(data))} autoComplete="off">
                    <DialogContent>
                        {loaded ?

                            <div className={classes.row}>
                                <Grid container alignItems={'center'}>
                                    <Grid item xs={4}>
                                        <Typography variant="h6">Название <span>*</span></Typography>
                                    </Grid>
                                    <Grid item xs={8}>
                                        <TextField id="outlined-basic-3"
                                                   name="name"
                                                   fullWidth
                                                   error={errors.name}
                                                   helperText={errors.name && "Обязательное поле"}
                                                   inputRef={register({required: true})}
                                                   variant="outlined" size={'small'}/>
                                    </Grid>
                                </Grid>
                            </div> : <LinearProgress/>
                        }
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleClose}>Отмена</Button>
                        <Button type="submit" color="primary">Сохранить</Button>
                    </DialogActions>
                </form>

            </Dialog>
        );
    }
;

export default ModelMarkDialog;
