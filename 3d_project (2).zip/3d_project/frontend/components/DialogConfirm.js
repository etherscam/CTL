import React, { useState } from 'react';
import { makeStyles } from '@material-ui/styles';
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogActions from "@material-ui/core/DialogActions";
import {Button, colors} from "@material-ui/core";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";
import Typography from "@material-ui/core/Typography";


const useStyles = makeStyles(theme => ({
    root: {
        padding: theme.spacing(7),
    },

    content: {
        flex: 1
    },
    dialog: {
        minWidth: 300
    },
    delete: {
        marginLeft: theme.spacing(5),
        color: theme.palette.error.main,
        '&:hover': {
            backgroundColor: 'rgba(236, 76, 71, 0.04)'
        }
    }
}));


const DialogConfirm = (props) => {
    const classes = useStyles();
    const {dialogText, open, setOpen, deleteItem, id} = props;

    const handleClose = () => {
        setOpen(false);
    };

    return (
        <Dialog
            open={open}
            onClose={handleClose}
            aria-labelledby="responsive-dialog-title"
            classes={{paper: classes.dialog}}
        >
            <DialogTitle id="alert-dialog-title"> <Typography variant="h5">Подтвердите действие</Typography></DialogTitle>
            <DialogContent>
                <DialogContentText><Typography variant="body1">{dialogText}</Typography></DialogContentText>
            </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} color="primary">Отмена</Button>
                    <Button className={classes.delete} onClick={deleteItem} color="primary">Удалить</Button>
                </DialogActions>

        </Dialog>
    );
};

export default DialogConfirm;
