import {gql} from '@apollo/client'

export const GET_MODEL = gql`
    query getModel($id: String!) {
        getModel (id: $id) {
            _id
            name
            dir
            lat
            lng
            geoReferenced
            marks {
                _id
                name
                modelId
                cameraPosition {
                    _id
                    position {
                        x
                        y
                        z
                    }
                    direction {
                        x
                        y
                        z
                    }
                    up {

                        x
                        y
                        z
                    }
                }
            }
        }
    }
`