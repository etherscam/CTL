import {gql} from '@apollo/client'

export const DELETE_MODEL = gql`
    mutation deleteModel($id: String!) {
        deleteModel(id: $id){
            _id
            name
            dir
            lat
            lng
            marks {
                _id
                name
                modelId
                cameraPosition {
                    _id
                    position {
                        x
                        y
                        z
                    }
                    direction {
                        x
                        y
                        z
                    }
                    up {

                        x
                        y
                        z
                    }
                }
            }
        }
    }
`