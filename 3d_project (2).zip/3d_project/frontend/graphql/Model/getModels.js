import {gql} from '@apollo/client'

export const GET_MODELS = gql`
    query getModels {
        getModels {
            _id
            name
            lat
            lng
        }
    }
`