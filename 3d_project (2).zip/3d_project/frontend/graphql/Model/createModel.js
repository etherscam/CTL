import {gql} from '@apollo/client'

export const CREATE_MODEL = gql`
    mutation createModel($input: ModelInput!) {
        createModel(input: $input){
            _id
            name
            dir
            lat
            lng
            marks {
                _id
                name
                modelId
                cameraPosition {
                    _id
                    position {
                        x
                        y
                        z
                    }
                    direction {
                        x
                        y
                        z
                    }
                    up {

                        x
                        y
                        z
                    }
                }
            }
        }
    }
`