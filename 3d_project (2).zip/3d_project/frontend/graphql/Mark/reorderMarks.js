import {gql} from '@apollo/client'

export const REORDER_MARKS = gql`
    mutation rearrangeMarks($marks: [String!]!, $id: String!) {
        rearrangeMarks(marks: $marks,id: $id){
            _id
            name
            dir
            lat
            lng
            geoReferenced
            marks {
                _id
                name
                modelId
                cameraPosition {
                    _id
                    position {
                        x
                        y
                        z
                    }
                    direction {
                        x
                        y
                        z
                    }
                    up {

                        x
                        y
                        z
                    }
                }
            }
        }
    }
`