import {gql} from '@apollo/client'

export const DELETE_MARK = gql`
    mutation deleteMark($id: String!) {
        deleteMark(id: $id){
            _id
            name
            modelId
            cameraPosition {
                _id
                position {
                    x
                    y
                    z
                }
                direction {
                    x
                    y
                    z
                }
                up {

                    x
                    y
                    z
                }
            }
        }
    }
`