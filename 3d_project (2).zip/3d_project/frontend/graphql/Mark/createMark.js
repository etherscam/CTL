import {gql} from '@apollo/client'

export const CREATE_MARK = gql`
    mutation createMark($input: MarkInput!, $modelId: String!) {
        createMark(input: $input, modelId: $modelId){
            _id
            name
            modelId
            cameraPosition {
                _id
                position {
                    x
                    y
                    z
                }
                direction {
                    x
                    y
                    z
                }
                up {

                    x
                    y
                    z
                }
            }
        }
    }
`
