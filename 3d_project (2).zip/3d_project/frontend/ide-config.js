// FOR IDEA IDE (LIKE WEBSTORM)

System.config({
  "paths": {
     "*": "./src/*",
  }
});