import React from 'react'
import Head from "next/head";
import {ThemeProvider} from '@material-ui/styles';
import theme from "theme";
import CssBaseline from '@material-ui/core/CssBaseline';
import App from 'next/app'
import "../styles/app.sass";
import 'react-perfect-scrollbar/dist/css/styles.css';
import "cesium/Build/Cesium/Widgets/widgets.css";
import {ApolloProvider} from "@apollo/client";
import {client} from "config/apolloConfig";

function MyApp({Component, pageProps}) {
    React.useEffect(() => {
        // Remove the server-side injected CSS.
        const jssStyles = document.querySelector('#jss-server-side');
        if (jssStyles) {
            jssStyles.parentElement.removeChild(jssStyles);
        }
    }, []);

    return (
        <ApolloProvider client={client}>
            <ThemeProvider theme={theme}>
                <Head>
                    <meta name="viewport"
                          content="minimum-scale=1, initial-scale=1, width=device-width, shrink-to-fit=no"/>
                    <title>Ctrl2GO “Тверь-Пилот”</title>
                </Head>
                <CssBaseline/>
                <Component {...pageProps} />
            </ThemeProvider>
        </ApolloProvider>
    )
}

MyApp.getInitialProps = async (appContext) => {
    const appProps = await App.getInitialProps(appContext)
    return {...appProps}
}

export default MyApp
