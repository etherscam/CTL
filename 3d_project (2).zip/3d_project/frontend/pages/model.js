import React, {useState} from "react";
import {useRouter} from "next/router";
import DashboardLayout from "layouts/DashboardLayout/DashboardLayout";
import ModelView from "components/Model/ModelView/ModelView";

const View = () => {
    const router = useRouter()
    const {id} = router.query;
    const [isOpen, setOpen] = useState(true);

    return (
        <DashboardLayout isOpen={isOpen} setOpen={setOpen}>
            <ModelView id={id} isOpen={isOpen} setOpen={setOpen}/>
        </DashboardLayout>
    )
}

export default View;
