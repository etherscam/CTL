import React from "react";
import SignIn from "components/SignIn/SignIn";

const Login = ({t}) => {
    return (
        <SignIn t={t}/>
    )
}

export default Login;
