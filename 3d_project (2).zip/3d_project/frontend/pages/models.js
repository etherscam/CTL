import React, {useState} from "react";
import ModelList from "components/Model/ModelList/ModelList";
import DashboardLayout from "layouts/DashboardLayout/DashboardLayout";
import ModelView from "components/Model/ModelView/ModelView";

const List = () => {
    const [isOpen, setOpen] = useState(true);
    return (
        <DashboardLayout isOpen={isOpen} setOpen={setOpen}>
            <ModelList isOpen={isOpen} setOpen={setOpen}/>
        </DashboardLayout>
    )
}

export default List;