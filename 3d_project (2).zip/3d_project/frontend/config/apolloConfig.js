import {ApolloClient, InMemoryCache, HttpLink, ApolloLink} from '@apollo/client';
import { onError } from "@apollo/client/link/error";
import fetch from "node-fetch";
import {API_URL} from "../config";
import {createUploadLink} from "apollo-upload-client";
import {buildAxiosFetch} from "@lifeomic/axios-fetch";
import * as axios from "axios";

const httpLink = createUploadLink({
    fetch: buildAxiosFetch(axios, (config, input, init) => ({
        ...config,
        onUploadProgress: init.onUploadProgress,
    })),
    uri: API_URL,
})
export const client = new ApolloClient({
    link: ApolloLink.from([
        onError(({graphQLErrors, networkError}) => {
            if (graphQLErrors)
                graphQLErrors.forEach(({message, locations, path}) =>
                    console.log(
                        `[GraphQL error]: Message: ${message}, Location: ${locations}, Path: ${path}`,
                    ),
                );
            if (networkError) console.log(`[Network error]: ${networkError}`);
        }),
        httpLink
    ]),
    cache: new InMemoryCache(),
});
