export const API_URL = process.env.NEXT_PUBLIC_API_URL ?  `${process.env.NEXT_PUBLIC_API_URL}/graphql` : 'https://api.ctrl4tver3d.ru/graphql';
