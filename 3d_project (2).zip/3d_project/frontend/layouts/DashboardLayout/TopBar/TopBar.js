import React from 'react';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import {
    AppBar,
    Box,
    Hidden,
    IconButton,
    Toolbar,
    makeStyles,
    SvgIcon
} from '@material-ui/core';
import {Menu as MenuIcon} from 'react-feather';
import Link from "next/link";

const useStyles = makeStyles((theme) => ({
    root: {
        zIndex: theme.zIndex.drawer + 100,
        boxShadow: 'none',
    },
    toolbar: {
        minHeight: 64
    },
    flexGrow: {
        flexGrow: 1
    },
}));

const TopBar = ({
                    className,
                    setOpen,
                    isOpen,
                    ...rest
                }) => {
    const classes = useStyles();

    return (
        <AppBar
            className={clsx(classes.root, className)}
            {...rest}
        >
            <Toolbar className={classes.toolbar}>

                {/*<Hidden mdDown>*/}
                {/*  <Link href="/">*/}
                {/*    <img*/}
                {/*        alt="Logo"*/}
                {/*        src="/logo-white.svg"*/}
                {/*        className={classes.logo}*/}
                {/*    />*/}
                {/*  </Link>*/}
                {/*</Hidden>*/}
                <div className={classes.flexGrow}/>
                <IconButton
                    color="inherit"
                    onClick={() => setOpen(!isOpen)}
                >
                    <MenuIcon/>
                </IconButton>

            </Toolbar>
        </AppBar>
    );
};

TopBar.propTypes = {
    className: PropTypes.string,
};


export default TopBar;
